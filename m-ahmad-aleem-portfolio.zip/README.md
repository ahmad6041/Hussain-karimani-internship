# M Ahmad Aleem — Portfolio

A responsive personal portfolio for M Ahmad Aleem, a front-end developer and IT student in Sahiwal, Pakistan. The page highlights his portfolio project, web development skills, and UI design practice. Built with semantic HTML, CSS, and vanilla JavaScript.

Featured portfolio highlights are stored as JSON in `index.html` and dynamically rendered by `script.js`. Update the JSON records to add or edit highlights. Personal details were based on the provided resume; the portfolio intentionally omits the home address and phone number.

## Run locally

Open `index.html` in a browser. No build step or dependencies are required. The Google Fonts and Unsplash images load over the internet.

## Portfolio features

- Previous/next controls with wraparound navigation
- Five-second autoplay that pauses on hover, keyboard focus, or when the tab is hidden
- Autoplay disabled when the visitor prefers reduced motion
- Accessible slide labels, live updates, and descriptive image text
- Direct email contact link: `engrmahmadaleem@gmail.com`

## Deploy

This is a static site. Upload the project files to GitHub Pages, Netlify, or Vercel. For GitHub Pages, choose the repository root as the site source.

## Project files

- `index.html` — portfolio content and JSON slide data
- `styles.css` — responsive layout, visual styling, and animations
- `script.js` — carousel and mobile navigation behavior
